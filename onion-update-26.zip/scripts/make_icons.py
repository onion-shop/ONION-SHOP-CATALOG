"""Иконки для экрана «Домой»: тёмная, белая, хэллоуинская. Размеры 180 (iOS), 192/512 (Android), maskable 512, favicon 48."""
from PIL import Image, ImageDraw, ImageFilter
import math, os
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets')
LOGO = Image.open(os.path.join(ROOT, 'logo.png')).convert('RGBA')
S = 1024  # рисуем крупно, потом уменьшаем

def vgrad(top, bot, size=S):
    im = Image.new('RGB', (size, size))
    px = im.load()
    for y in range(size):
        t = y / (size - 1)
        c = tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3))
        for x in range(size): px[x, y] = c
    return im

def radial(cx, cy, r, col, alpha=255, size=S):
    m = Image.new('L', (size, size), 0)
    d = ImageDraw.Draw(m); d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=alpha)
    m = m.filter(ImageFilter.GaussianBlur(r * 0.45))
    return Image.new('RGB', (size, size), col), m

def put_logo(base, scale, dx=0, dy=0, shadow=None):
    sz = int(S * scale)
    lg = LOGO.resize((sz, sz), Image.LANCZOS)
    x = (S - sz) // 2 + dx; y = (S - sz) // 2 + dy
    if shadow:
        sh = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        a = lg.split()[3].point(lambda v: int(v * shadow[1]))
        sh.paste(Image.new('RGBA', (sz, sz), shadow[0] + (255,)), (x, y + int(S * .012)), a)
        sh = sh.filter(ImageFilter.GaussianBlur(S * .014))
        base.alpha_composite(sh)
    base.alpha_composite(lg, (x, y))

def pumpkin(d, cx, cy, r):
    # тыква: несколько долей + стебель + лицо
    for k, dx in enumerate([-.52, .52, -.26, .26, 0]):
        w = r * (.62 if k < 2 else .7 if k < 4 else .72)
        col = (232, 112, 20) if k < 4 else (255, 140, 26)
        d.ellipse([cx + dx * r - w, cy - r * .86, cx + dx * r + w, cy + r * .86], fill=col)
    d.ellipse([cx - r * .55, cy - r * .86, cx + r * .55, cy + r * .86], fill=(255, 142, 28))
    d.polygon([(cx - r * .09, cy - r * .86), (cx + r * .12, cy - r * .86), (cx + r * .2, cy - r * 1.18), (cx - r * .02, cy - r * 1.14)], fill=(52, 120, 60))
    face = (60, 20, 70)
    d.polygon([(cx - r * .42, cy - r * .1), (cx - r * .15, cy - r * .1), (cx - r * .28, cy - r * .36)], fill=face)
    d.polygon([(cx + r * .42, cy - r * .1), (cx + r * .15, cy - r * .1), (cx + r * .28, cy - r * .36)], fill=face)
    d.polygon([(cx - r * .5, cy + r * .2), (cx - r * .25, cy + r * .5), (cx - r * .12, cy + r * .3), (cx, cy + r * .52), (cx + r * .12, cy + r * .3), (cx + r * .25, cy + r * .5), (cx + r * .5, cy + r * .2), (cx, cy + r * .08)], fill=face)

def bat(d, cx, cy, w, col):
    h = w * .42
    d.ellipse([cx - w * .09, cy - h * .3, cx + w * .09, cy + h * .45], fill=col)
    for s in (-1, 1):
        pts = [(cx + s * w * .06, cy - h * .05), (cx + s * w * .3, cy - h * .55), (cx + s * w * .5, cy - h * .2),
               (cx + s * w * .46, cy + h * .25), (cx + s * w * .34, cy + h * .08), (cx + s * w * .22, cy + h * .3), (cx + s * w * .1, cy + h * .08)]
        d.polygon(pts, fill=col)
    d.polygon([(cx - w * .08, cy - h * .28), (cx - w * .04, cy - h * .6), (cx, cy - h * .3)], fill=col)
    d.polygon([(cx + w * .08, cy - h * .28), (cx + w * .04, cy - h * .6), (cx, cy - h * .3)], fill=col)

def make(kind):
    if kind == 'dark':
        base = Image.new('RGBA', (S, S), (5, 10, 29, 255))
        g, m = radial(S * .5, S * .5, S * .42, (20, 60, 140), 90); base.paste(g, (0, 0), m)
        put_logo(base, .70, shadow=((0, 10, 40), .6))
    elif kind == 'white':
        base = vgrad((255, 255, 255), (222, 232, 246)).convert('RGBA')
        put_logo(base, .70, shadow=((60, 100, 170), .28))
    else:
        base = vgrad((58, 16, 96), (12, 4, 30)).convert('RGBA')
        g, m = radial(S * .47, S * .48, S * .33, (255, 122, 24), 200); base.paste(g, (0, 0), m)
        d = ImageDraw.Draw(base)
        for (x, y, w) in [(.2, .2, .17), (.82, .16, .12), (.12, .46, .09)]:
            bat(d, S * x, S * y, S * w, (14, 6, 26))
        put_logo(base, .58, dx=-int(S * .035), dy=-int(S * .035), shadow=((0, 0, 0), .7))
        d = ImageDraw.Draw(base)
        pumpkin(d, S * .8, S * .8, S * .12)
    return base

def save(img, name, size, mask=False):
    im = img
    if mask:  # maskable: логотип в «безопасной зоне» 80%
        bg = Image.new('RGBA', (S, S), img.getpixel((4, 4)))
        small = img.resize((int(S * .8), int(S * .8)), Image.LANCZOS)
        bg.paste(small, (int(S * .1), int(S * .1)))
        im = bg
    out = im.resize((size, size), Image.LANCZOS)
    out.convert('RGB').save(os.path.join(ROOT, 'icons', name), optimize=True)

os.makedirs(os.path.join(ROOT, 'icons'), exist_ok=True)
for k in ('dark', 'white', 'halloween'):
    im = make(k)
    save(im, k + '-180.png', 180); save(im, k + '-192.png', 192); save(im, k + '-512.png', 512)
    save(im, k + '-maskable-512.png', 512, mask=True); save(im, k + '-48.png', 48)
print('icons ok')
